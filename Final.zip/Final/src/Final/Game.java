package Final;

import java.io.IOException;

public class Game
{

	public static void main(String[] args) throws IOException 
	{
		new GuessWho();
	}

}
